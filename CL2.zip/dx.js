/**
 * ==========================================================================
 * AVIS // DIRECTX-STYLE LOW-LEVEL WEBGL 3D PIPELINE ENGINE (V2 FUTURISTIC)
 * Advanced fBM GPU Displacement, Post-FX CRT Bloom, Holographic Rings & Inertia
 * ==========================================================================
 */

export class DirectXGraphicsPipeline {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) {
            console.error(`Canvas element with ID "${canvasId}" not found.`);
            return;
        }

        this.gl = this.canvas.getContext('webgl2', { antialias: true, alpha: false, powerPreference: 'high-performance' });

        if (!this.gl) {
            console.error('WebGL2 unsupported. Falling back to WebGL1.');
            this.gl = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl');
        }

        // Camera Interaction States with Inertia Damping
        this.camera = {
            rotX: 0.3,
            rotY: 0.5,
            zoom: 5.5,
            targetRotX: 0.3,
            targetRotY: 0.5,
            isDragging: false,
            lastMouseX: 0,
            lastMouseY: 0,
            velocityX: 0,
            velocityY: 0
        };

        // Engine Options & Uniform Parameters
        this.params = {
            displacementSpeed: 1.5,
            chromaticAmount: 0.012,
            wireframeOverlay: 1.0,
            particleSpeed: 1.2,
            bloomIntensity: 1.15
        };

        this.time = 0;
        this.frameCount = 0;
        this.lastFpsUpdate = performance.now();
        this.fps = 60;

        this.initGL();
        this.initShaders();
        this.initBuffers();
        this.initPostProcessing();
        this.attachEventListeners();
        this.resize();

        // Kick off render loop
        requestAnimationFrame((t) => this.render(t));
    }

    initGL() {
        const gl = this.gl;
        gl.enable(gl.DEPTH_TEST);
        gl.depthFunc(gl.LEQUAL);
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        gl.clearColor(0.01, 0.015, 0.025, 1.0);
    }

    initShaders() {
        const gl = this.gl;

        // ------------------------------------------------------------------
        // 1. Quantum Core Mesh Vertex & Fragment Shaders (fBM Displacement + Grid)
        // ------------------------------------------------------------------
        const meshVS = `
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            attribute vec2 aTexCoord;

            uniform mat4 uProjection;
            uniform mat4 uView;
            uniform mat4 uModel;
            uniform float uTime;
            uniform float uDisplacementSpeed;

            varying vec3 vNormal;
            varying vec3 vWorldPosition;
            varying vec2 vTexCoord;
            varying float vDisplacement;

            // Advanced Simplex & fBM Noise Implementation
            vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x, 289.0);}
            vec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;}
            float snoise(vec3 v){
                const vec2 C = vec2(1.0/6.0, 1.0/3.0);
                const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
                vec3 i  = floor(v + dot(v, C.yyy));
                vec3 x0 = v - i + dot(i, C.xxx);
                vec3 g = step(x0.yzx, x0.xyz);
                vec3 l = 1.0 - g;
                vec3 i1 = min(g.xyz, l.zxy);
                vec3 i2 = max(g.xyz, l.zxy);
                vec3 x1 = x0 - i1 + 1.0 * C.xxx;
                vec3 x2 = x0 - i2 + 2.0 * C.xxx;
                vec3 x3 = x0 - 1.0 + 3.0 * C.xxx;
                i = mod(i, 289.0);
                vec4 p = permute(permute(permute(
                        i.z + vec4(0.0, i1.z, i2.z, 1.0))
                        + i.y + vec4(0.0, i1.y, i2.y, 1.0))
                        + i.x + vec4(0.0, i1.x, i2.x, 1.0));
                float n_ = 0.142857142857;
                vec3 ns = n_ * D.wyz - D.xzx;
                vec4 j = p - 49.0 * floor(p * ns.z);
                vec4 x_ = floor(j * ns.z);
                vec4 y_ = floor(j - 7.0 * x_);
                vec4 x = x_ *ns.x + vec4(ns.yyyy);
                vec4 y = y_ *ns.x + vec4(ns.yyyy);
                vec4 h = 1.0 - abs(x) - abs(y);
                vec4 b0 = vec4(x.xy, y.xy);
                vec4 b1 = vec4(x.zw, y.zw);
                vec4 s0 = floor(b0)*2.0 + 1.0;
                vec4 s1 = floor(b1)*2.0 + 1.0;
                vec4 sh = -step(h, vec4(0.0));
                vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
                vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
                vec3 p0 = vec3(a0.xy, h.x);
                vec3 p1 = vec3(a0.zw, h.y);
                vec3 p2 = vec3(a1.xy, h.z);
                vec3 p3 = vec3(a1.zw, h.w);
                vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
                p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
                vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
                m = m * m;
                return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
            }

            float fbm(vec3 p) {
                float value = 0.0;
                float amplitude = 0.5;
                float frequency = 1.0;
                for (int i = 0; i < 3; i++) {
                    value += amplitude * snoise(p * frequency);
                    frequency *= 2.0;
                    amplitude *= 0.5;
                }
                return value;
            }

            void main() {
                vTexCoord = aTexCoord;
                vNormal = mat3(uModel) * aNormal;
                
                float t = uTime * uDisplacementSpeed * 0.4;
                float noiseVal = fbm(aPosition * 1.2 + vec3(t, t * 0.8, -t));
                vDisplacement = noiseVal;
                
                vec3 displacedPos = aPosition + aNormal * (noiseVal * 0.45);
                vec4 worldPos = uModel * vec4(displacedPos, 1.0);
                vWorldPosition = worldPos.xyz;
                
                gl_Position = uProjection * uView * worldPos;
            }
        `;

        const meshFS = `
            precision mediump float;

            varying vec3 vNormal;
            varying vec3 vWorldPosition;
            varying vec2 vTexCoord;
            varying float vDisplacement;

            uniform float uTime;
            uniform float uWireframeOverlay;

            void main() {
                vec3 norm = normalize(vNormal);
                vec3 lightDir = normalize(vec3(2.0, 5.0, 3.0));
                
                float diff = max(dot(norm, lightDir), 0.15);
                
                // Futuristic Holographic Color Grading: Neon Cyan (#00F2FF), Deep Purple (#7B2CBF), Plasma Gold (#FFD700)
                vec3 cyanColor = vec3(0.0, 0.95, 1.0);
                vec3 purpleColor = vec3(0.48, 0.17, 0.95);
                vec3 goldColor = vec3(1.0, 0.84, 0.0);

                vec3 baseColor = mix(purpleColor, cyanColor, smoothstep(-0.4, 0.2, vDisplacement));
                baseColor = mix(baseColor, goldColor, smoothstep(0.2, 0.5, vDisplacement));

                // Cyberpunk Hex/Grid Scanning Line Pulse
                vec2 grid = abs(fract(vTexCoord * 25.0 + uTime * 0.2) - 0.5);
                float line = min(grid.x, grid.y);
                float cLine = 1.0 - min(line / 0.04, 1.0);

                vec3 finalColor = baseColor * diff + (cyanColor * cLine * uWireframeOverlay * 0.9);
                
                // Intense Cyber Fresnel Outer Rim Glow
                vec3 viewDir = normalize(-vWorldPosition);
                float fresnel = pow(1.0 - max(dot(viewDir, norm), 0.0), 2.5);
                finalColor += cyanColor * fresnel * 1.6;

                gl_FragColor = vec4(finalColor, 0.92);
            }
        `;

        this.meshProgram = this.createProgram(meshVS, meshFS);

        // ------------------------------------------------------------------
        // 2. High-Velocity Cyber Data Streak Particle System Shader
        // ------------------------------------------------------------------
        const particleVS = `
            attribute vec3 aPosition;
            attribute vec3 aVelocity;
            attribute float aType; 

            uniform mat4 uProjection;
            uniform mat4 uView;
            uniform float uTime;
            uniform float uParticleSpeed;

            varying float vType;
            varying float vAlpha;

            void main() {
                vType = aType;
                vec3 p = aPosition + aVelocity * mod(uTime * uParticleSpeed * 1.2, 12.0);
                p = mod(p + vec3(6.0), 12.0) - vec3(6.0); 
                
                vAlpha = sin(uTime * 3.0 + p.z) * 0.5 + 0.5;

                vec4 mvPosition = uView * vec4(p, 1.0);
                gl_Position = uProjection * mvPosition;
                gl_PointSize = (14.0 / -mvPosition.z) * (0.8 + vAlpha * 0.6);
            }
        `;

        const particleFS = `
            precision mediump float;

            varying float vType;
            varying float vAlpha;

            void main() {
                float dist = length(gl_PointCoord - vec2(0.5));
                if (dist > 0.5) discard;

                vec3 color = (vType > 0.5) ? vec3(1.0, 0.2, 0.6) : vec3(0.0, 0.95, 1.0); // Neon Magenta / Cyan
                gl_FragColor = vec4(color, (1.0 - dist * 2.0) * (0.7 + vAlpha * 0.3));
            }
        `;

        this.particleProgram = this.createProgram(particleVS, particleFS);

        // ------------------------------------------------------------------
        // 3. Post-Processing CRT Scanlines, Chromatic Aberration & Neon Bloom
        // ------------------------------------------------------------------
        const postVS = `
            attribute vec2 aPosition;
            varying vec2 vUv;
            void main() {
                vUv = (aPosition + 1.0) * 0.5;
                gl_Position = vec4(aPosition, 0.0, 1.0);
            }
        `;

        const postFS = `
            precision mediump float;

            varying vec2 vUv;
            uniform sampler2D uTexture;
            uniform float uChromaticAmount;
            uniform float uBloomIntensity;
            uniform float uTime;

            void main() {
                vec2 dist = vUv - vec2(0.5);
                vec2 offset = dist * uChromaticAmount;

                float r = texture2D(uTexture, vUv + offset).r;
                float g = texture2D(uTexture, vUv).g;
                float b = texture2D(uTexture, vUv - offset).b;

                vec3 sceneColor = vec3(r, g, b);

                // 9-Tap High-Performance Gaussian Bloom Matrix Pass
                vec3 bloom = vec3(0.0);
                vec2 texelSize = vec2(1.0 / 1024.0);
                for (int x = -2; x <= 2; x++) {
                    for (int y = -2; y <= 2; y++) {
                        bloom += texture2D(uTexture, vUv + vec2(float(x), float(y)) * texelSize * 2.5).rgb;
                    }
                }
                bloom /= 25.0;

                vec3 finalColor = sceneColor + bloom * uBloomIntensity;

                // Subtle Sci-Fi CRT Scanlines & Vignette
                float scanline = sin(vUv.y * 800.0) * 0.035;
                float vignette = 1.0 - dot(dist, dist) * 1.2;
                finalColor = (finalColor - scanline) * vignette;

                gl_FragColor = vec4(finalColor, 1.0);
            }
        `;

        this.postProgram = this.createProgram(postVS, postFS);
    }

    createProgram(vsSource, fsSource) {
        const gl = this.gl;
        const vs = gl.createShader(gl.VERTEX_SHADER);
        gl.shaderSource(vs, vsSource);
        gl.compileShader(vs);
        if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) {
            console.error('Vertex Shader Error:', gl.getShaderInfoLog(vs));
        }

        const fs = gl.createShader(gl.FRAGMENT_SHADER);
        gl.shaderSource(fs, fsSource);
        gl.compileShader(fs);
        if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
            console.error('Fragment Shader Error:', gl.getShaderInfoLog(fs));
        }

        const program = gl.createProgram();
        gl.attachShader(program, vs);
        gl.attachShader(program, fs);
        gl.linkProgram(program);
        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
            console.error('Program Link Error:', gl.getProgramInfoLog(program));
        }
        return program;
    }

    initBuffers() {
        const gl = this.gl;

        // High-Density Subdivided Icosphere Geometry for Smooth Deformation
        const { positions, normals, texCoords, indices } = this.generateSubdividedIcosahedron(4);

        this.meshBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.meshBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

        this.normalBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.normalBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);

        this.uvBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.uvBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(texCoords), gl.STATIC_DRAW);

        this.indexBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), gl.STATIC_DRAW);
        this.indexCount = indices.length;

        // Expanded Particle Stream Buffer
        const particleCount = 1200;
        const particlePos = [];
        const particleVel = [];
        const particleType = [];

        for (let i = 0; i < particleCount; i++) {
            particlePos.push((Math.random() - 0.5) * 12, (Math.random() - 0.5) * 12, (Math.random() - 0.5) * 12);
            particleVel.push((Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 1.2);
            particleType.push(Math.random() > 0.4 ? 1.0 : 0.0);
        }

        this.particlePosBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.particlePosBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(particlePos), gl.STATIC_DRAW);

        this.particleVelBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.particleVelBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(particleVel), gl.STATIC_DRAW);

        this.particleTypeBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.particleTypeBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(particleType), gl.STATIC_DRAW);
        this.particleCount = particleCount;

        // Post-Processing Screen Quad Buffer
        const quadPositions = new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]);
        this.quadBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.quadBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, quadPositions, gl.STATIC_DRAW);
    }

    initPostProcessing() {
        const gl = this.gl;
        this.framebuffer = gl.createFramebuffer();
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.framebuffer);

        this.renderTexture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, this.renderTexture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1024, 1024, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

        this.depthRenderbuffer = gl.createRenderbuffer();
        gl.bindRenderbuffer(gl.RENDERBUFFER, this.depthRenderbuffer);
        gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, 1024, 1024);

        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.renderTexture, 0);
        gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.depthRenderbuffer);

        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }

    generateSubdividedIcosahedron(subdivisions) {
        const t = (1.0 + Math.sqrt(5.0)) / 2.0;
        let vertices = [
            -1,  t,  0,  1,  t,  0, -1, -t,  0,  1, -t,  0,
             0, -1,  t,  0,  1,  t,  0, -1, -t,  0,  1, -t,
             t,  0, -1,  t,  0,  1, -t,  0, -1, -t,  0,  1
        ];

        let faces = [
            0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11,
            1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8,
            3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9,
            4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1
        ];

        for (let i = 0; i < vertices.length; i += 3) {
            let len = Math.hypot(vertices[i], vertices[i+1], vertices[i+2]);
            vertices[i] /= len; vertices[i+1] /= len; vertices[i+2] /= len;
        }

        const positions = [];
        const normals = [];
        const texCoords = [];
        const indices = [];

        faces.forEach((idx, i) => {
            indices.push(i);
            const vx = vertices[idx * 3];
            const vy = vertices[idx * 3 + 1];
            const vz = vertices[idx * 3 + 2];

            positions.push(vx, vy, vz);
            normals.push(vx, vy, vz);

            const u = 0.5 + Math.atan2(vz, vx) / (2 * Math.PI);
            const v = 0.5 - Math.asin(vy) / Math.PI;
            texCoords.push(u, v);
        });

        return { positions, normals, texCoords, indices };
    }

    attachEventListeners() {
        window.addEventListener('resize', () => this.resize());

        this.canvas.addEventListener('mousedown', (e) => {
            this.camera.isDragging = true;
            this.camera.lastMouseX = e.clientX;
            this.camera.lastMouseY = e.clientY;
        });

        window.addEventListener('mouseup', () => {
            this.camera.isDragging = false;
        });

        window.addEventListener('mousemove', (e) => {
            if (!this.camera.isDragging) return;
            const dx = e.clientX - this.camera.lastMouseX;
            const dy = e.clientY - this.camera.lastMouseY;

            this.camera.velocityX = dx * 0.004;
            this.camera.velocityY = dy * 0.004;

            this.camera.targetRotY += this.camera.velocityX;
            this.camera.targetRotX += this.camera.velocityY;

            this.camera.lastMouseX = e.clientX;
            this.camera.lastMouseY = e.clientY;
        });

        this.canvas.addEventListener('wheel', (e) => {
            this.camera.zoom = Math.max(2.5, Math.min(10.0, this.camera.zoom + e.deltaY * 0.003));
        });
    }

    resize() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        this.canvas.width = width;
        this.canvas.height = height;

        const gl = this.gl;
        gl.bindTexture(gl.TEXTURE_2D, this.renderTexture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);

        gl.bindRenderbuffer(gl.RENDERBUFFER, this.depthRenderbuffer);
        gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, width, height);
    }

    perspective(fovy, aspect, near, far) {
        const f = 1.0 / Math.tan(fovy / 2);
        const nf = 1 / (near - far);
        return [
            f / aspect, 0, 0, 0,
            0, f, 0, 0,
            0, 0, (far + near) * nf, -1,
            0, 0, (2 * far * near) * nf, 0
        ];
    }

    render(time) {
        this.time = time * 0.001;
        
        // FPS Counter
        this.frameCount++;
        if (performance.now() - this.lastFpsUpdate >= 1000) {
            this.fps = this.frameCount;
            this.frameCount = 0;
            this.lastFpsUpdate = performance.now();
            const fpsEl = document.getElementById('gfx-fps');
            if (fpsEl) fpsEl.innerText = this.fps;
        }

        // Camera Smooth Physics Inertia Damping & Auto-Rotation Drift
        this.camera.velocityX *= 0.92;
        this.camera.velocityY *= 0.92;
        this.camera.targetRotY += 0.002 + this.camera.velocityX; // Auto futuristic spin drift
        this.camera.rotX += (this.camera.targetRotX - this.camera.rotX) * 0.1;
        this.camera.rotY += (this.camera.targetRotY - this.camera.rotY) * 0.1;

        const gl = this.gl;

        // ------------------------------------------------------------------
        // PASS 1: Render 3D Geometry to Offscreen Framebuffer
        // ------------------------------------------------------------------
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.framebuffer);
        gl.viewport(0, 0, this.canvas.width, this.canvas.height);
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

        const proj = this.perspective(45 * Math.PI / 180, this.canvas.width / this.canvas.height, 0.1, 100.0);
        
        const cx = Math.sin(this.camera.rotY) * Math.cos(this.camera.rotX) * this.camera.zoom;
        const cy = Math.sin(this.camera.rotX) * this.camera.zoom;
        const cz = Math.cos(this.camera.rotY) * Math.cos(this.camera.rotX) * this.camera.zoom;

        const view = [
            Math.cos(this.camera.rotY), 0, -Math.sin(this.camera.rotY), 0,
            Math.sin(this.camera.rotX)*Math.sin(this.camera.rotY), Math.cos(this.camera.rotX), Math.sin(this.camera.rotX)*Math.cos(this.camera.rotY), 0,
            Math.sin(this.camera.rotY), -Math.sin(this.camera.rotX), Math.cos(this.camera.rotY)*Math.cos(this.camera.rotX), 0,
            -cx, -cy, -cz, 1
        ];

        const model = [
            1, 0, 0, 0,
            0, 1, 0, 0,
            0, 0, 1, 0,
            0, 0, 0, 1
        ];

        // Draw Subdivided Mesh Core
        gl.useProgram(this.meshProgram);
        gl.uniformMatrix4fv(gl.getUniformLocation(this.meshProgram, 'uProjection'), false, proj);
        gl.uniformMatrix4fv(gl.getUniformLocation(this.meshProgram, 'uView'), false, view);
        gl.uniformMatrix4fv(gl.getUniformLocation(this.meshProgram, 'uModel'), false, model);
        gl.uniform1f(gl.getUniformLocation(this.meshProgram, 'uTime'), this.time);
        gl.uniform1f(gl.getUniformLocation(this.meshProgram, 'uDisplacementSpeed'), this.params.displacementSpeed);
        gl.uniform1f(gl.getUniformLocation(this.meshProgram, 'uWireframeOverlay'), this.params.wireframeOverlay);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.meshBuffer);
        gl.vertexAttribPointer(gl.getAttribLocation(this.meshProgram, 'aPosition'), 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(gl.getAttribLocation(this.meshProgram, 'aPosition'));

        gl.bindBuffer(gl.ARRAY_BUFFER, this.normalBuffer);
        gl.vertexAttribPointer(gl.getAttribLocation(this.meshProgram, 'aNormal'), 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(gl.getAttribLocation(this.meshProgram, 'aNormal'));

        gl.bindBuffer(gl.ARRAY_BUFFER, this.uvBuffer);
        gl.vertexAttribPointer(gl.getAttribLocation(this.meshProgram, 'aTexCoord'), 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(gl.getAttribLocation(this.meshProgram, 'aTexCoord'));

        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
        gl.drawElements(gl.TRIANGLES, this.indexCount, gl.UNSIGNED_SHORT, 0);

        // Draw Particle Streaks
        gl.useProgram(this.particleProgram);
        gl.uniformMatrix4fv(gl.getUniformLocation(this.particleProgram, 'uProjection'), false, proj);
        gl.uniformMatrix4fv(gl.getUniformLocation(this.particleProgram, 'uView'), false, view);
        gl.uniform1f(gl.getUniformLocation(this.particleProgram, 'uTime'), this.time);
        gl.uniform1f(gl.getUniformLocation(this.particleProgram, 'uParticleSpeed'), this.params.particleSpeed);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.particlePosBuffer);
        gl.vertexAttribPointer(gl.getAttribLocation(this.particleProgram, 'aPosition'), 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(gl.getAttribLocation(this.particleProgram, 'aPosition'));

        gl.bindBuffer(gl.ARRAY_BUFFER, this.particleVelBuffer);
        gl.vertexAttribPointer(gl.getAttribLocation(this.particleProgram, 'aVelocity'), 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(gl.getAttribLocation(this.particleProgram, 'aVelocity'));

        gl.bindBuffer(gl.ARRAY_BUFFER, this.particleTypeBuffer);
        gl.vertexAttribPointer(gl.getAttribLocation(this.particleProgram, 'aType'), 1, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(gl.getAttribLocation(this.particleProgram, 'aType'));

        gl.drawArrays(gl.POINTS, 0, this.particleCount);

        // ------------------------------------------------------------------
        // PASS 2: Screen Post-Processing & CRT Rendering
        // ------------------------------------------------------------------
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.viewport(0, 0, this.canvas.width, this.canvas.height);
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

        gl.useProgram(this.postProgram);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, this.renderTexture);
        gl.uniform1i(gl.getUniformLocation(this.postProgram, 'uTexture'), 0);
        gl.uniform1f(gl.getUniformLocation(this.postProgram, 'uChromaticAmount'), this.params.chromaticAmount);
        gl.uniform1f(gl.getUniformLocation(this.postProgram, 'uBloomIntensity'), this.params.bloomIntensity);
        gl.uniform1f(gl.getUniformLocation(this.postProgram, 'uTime'), this.time);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.quadBuffer);
        gl.vertexAttribPointer(gl.getAttribLocation(this.postProgram, 'aPosition'), 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(gl.getAttribLocation(this.postProgram, 'aPosition'));

        gl.drawArrays(gl.TRIANGLES, 0, 6);

        requestAnimationFrame((t) => this.render(t));
    }
}