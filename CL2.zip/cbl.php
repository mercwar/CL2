<?php
global $git;
$git = 'false';

if (isset($_GET['git']) && $_GET['git'] == 'true') {
    $git = $_GET['git']; 

    define('REPO_ROOT_DIR', ''); 
    define('REPO_USER_LIVES', "/");
} else {
 
    define('REPO_ROOT_DIR', "./");  
    // Root is separate from path now
    define('REPO_USER_LIVES', 'repositories' . "/");
}

if (isset($_GET['user']) && trim($_GET['user']) !== '') {
    define('USER_NAME', trim($_GET['user']));
} else {
    define('USER_NAME', 'mercwar'); 
}

define('REPO_FILES_LIVE', USER_NAME);

// Path is completely independent
if (isset($_GET['path']) && trim($_GET['path']) !== '') {
    define('REPO_PATH', trim($_GET['path']));
} else {
    define('REPO_PATH', ''); 
}

// Root parameter independent handling
$rootParam = (isset($_GET['root']) && trim($_GET['root']) !== '') ? trim($_GET['root']) : 'repositories';

if (isset($_GET['file']) && trim($_GET['file']) !== '') {
    define('REPO_PATH_FILE', trim($_GET['file']));
} else {
    define('REPO_PATH_FILE', ''); 
}

// Build raw base cleanly using root and user
$rawBase = REPO_ROOT_DIR . $rootParam . '/' . REPO_FILES_LIVE;
$resolvedBase = realpath($rawBase);

define('REPO_BASE_DIR', $resolvedBase ? $resolvedBase : rtrim($rawBase, '\\/'));

?>