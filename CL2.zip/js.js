// ==========================================================================
// AVIS // Telemetry Terminal Frontend Engine (Unified GitHub & Local Protocol)
// ==========================================================================

import { DirectXGraphicsPipeline } from "./dx.js";

let repositories = [];
let currentRepo = null;
let currentFile = null;
let activeViewMode = 'preview'; // Synchronized with global view toggle handler
let expandedFolders = new Set(); // Tracks open folder paths across tree re-renders

window.addEventListener('DOMContentLoaded', () => {
    // Locate the "Live Load" submit button inside the environment form framework
    const liveLoadButton = document.querySelector('#env-config-form button[type="submit"]');
    if (liveLoadButton) {
        liveLoadButton.click();
    }
     
    const searchInput = document.getElementById('repo-search');
    if (searchInput) {
        searchInput.addEventListener('input', filterRepositories);
    }
});


async function loadRepositories() {
    const listEl = document.getElementById('repo-list');
    if (!listEl) return;
    
    const urlParams = new URLSearchParams(window.location.search);
    const isRemoteMode = urlParams.get('git') === 'true';
    const currentRoot = urlParams.get('root') || document.getElementById('env-root-input')?.value || 'repositories';
    const currentUsername = urlParams.get('user') || document.getElementById('env-user-input')?.value || 'mercwar';
    const currentRepoParam = urlParams.get('repo') || '';
    const currentPath = urlParams.get('path') || document.getElementById('env-path-input')?.value || '';
    const isAction = urlParams.get('action') || 'form_load';
    const targetEndpoint = isRemoteMode ? 'git.php' : 'php.php';

    listEl.innerHTML = `<div class="p-6 text-center text-slate-500 text-xs"><i class="fa-solid fa-spinner animate-spin mr-2"></i> Scanning ${isRemoteMode ? 'GitHub (git.php)' : 'Local (php.php)'} repositories...</div>`;

    try {
        let response = await fetch(`${targetEndpoint}?action=${isAction}&git=${isRemoteMode}&root=${encodeURIComponent(currentRoot)}&user=${encodeURIComponent(currentUsername)}&repo=${encodeURIComponent(currentRepoParam)}&path=${encodeURIComponent(currentPath)}`);
        let result = await response.json();
        
        if (result.status !== 'success') {
            response = await fetch(`${targetEndpoint}?action=list_repos&git=${isRemoteMode}&root=${encodeURIComponent(currentRoot)}&user=${encodeURIComponent(currentUsername)}&repo=${encodeURIComponent(currentRepoParam)}&path=${encodeURIComponent(currentPath)}`);
            result = await response.json();
        }

        if (result.status === 'success') {
            repositories = result.data;
            renderRepositories(repositories);

            let targetRepo = null;
            if (currentRepoParam) {
                targetRepo = repositories.find(r => r.name.toLowerCase() === currentRepoParam.toLowerCase());
            }

            // Fallback rule: Pick "Stargate" or the first repo without a ".git" extension
            if (!targetRepo && repositories.length > 0) {
                targetRepo = repositories.find(r => r.name.toLowerCase() === 'stargate') ||
                             repositories.find(r => !r.name.toLowerCase().endsWith('.git')) ||
                             repositories[0];
            }

            if (targetRepo && (!currentRepo || currentRepo.name !== targetRepo.name)) {
                await selectRepository(targetRepo);
            }
        } else {
            listEl.innerHTML = `<div class="p-6 text-center text-red-400 text-xs">${result.avis || 'Failed to list repositories.'}</div>`;
        }
    } catch (e) {
        console.error('Failed to load repositories', e);
        listEl.innerHTML = `<div class="p-6 text-center text-red-400 text-xs">Failed to connect to active backend engine (${targetEndpoint}).</div>`;
    }
}
window.loadRepositories = loadRepositories;

function renderRepositories(repos) {
    const listEl = document.getElementById('repo-list');
    const countEl = document.getElementById('repo-count');
    if (!listEl) return;
    if (countEl) countEl.innerText = `${repos.length} detected`;
    
    if (repos.length === 0) {
        listEl.innerHTML = `<div class="p-6 text-center text-slate-500 text-xs">No repositories found.</div>`;
        return;
    }

    listEl.innerHTML = '';
    repos.forEach(repo => {
        const isSelected = currentRepo && currentRepo.name === repo.name;
        const item = document.createElement('div');
        item.className = `p-2.5 rounded-sm cursor-pointer transition-all border ${isSelected ? 'bg-red-950/40 border-red-500/60 text-white shadow-[0_0_12px_rgba(255,59,48,0.25)]' : 'bg-black/40 border-red-900/30 hover:border-red-500/30 text-slate-300'}`;
        item.onclick = () => selectRepository(repo);
        
        item.innerHTML = `
            <div class="flex items-center justify-between mb-1">
                <span class="font-semibold text-xs flex items-center space-x-2">
                    <i class="fa-brands fa-git-alt text-red-500"></i>
                    <span class="truncate">${repo.name}</span>
                </span>
                <span class="text-[10px] font-mono px-1 py-0.2 rounded-sm bg-black/65 text-amber-400 border border-amber-500/30">${repo.branch || 'main'}</span>
            </div>
            <p class="text-[10px] text-slate-500 font-mono truncate">${repo.path}</p>
        `;
        listEl.appendChild(item);
    });
}

function filterRepositories() {
    const searchInput = document.getElementById('repo-search');
    if (!searchInput) return;
    const query = searchInput.value.toLowerCase();
    const filtered = repositories.filter(r => r.name.toLowerCase().includes(query) || r.path.toLowerCase().includes(query));
    renderRepositories(filtered);
}
window.filterRepositories = filterRepositories;

async function selectRepository(repo) {
    if (!repo) return;
    currentRepo = repo;
    expandedFolders.clear();
    
    const url = new URL(window.location.href);
    url.searchParams.set('repo', repo.name);
    window.history.pushState({}, '', url);

    if (typeof repositories !== 'undefined') {
        renderRepositories(repositories);
    }
    
    const activeRepoNameEl = document.getElementById('active-repo-name');
    const fileCountEl = document.getElementById('file-count');
    if (activeRepoNameEl) activeRepoNameEl.innerText = repo.name || 'Unknown Repository';

    const urlParams = new URLSearchParams(window.location.search);
    const isRemoteMode = urlParams.get('git') === 'true';
    const currentRoot = urlParams.get('root') || 'repositories';
    const currentUsername = urlParams.get('user') || 'mercwar';
    const targetEndpoint = isRemoteMode ? 'git.php' : 'php.php';

    try {
        const response = await fetch(`${targetEndpoint}?action=get_file&git=${isRemoteMode}&root=${encodeURIComponent(currentRoot)}&user=${encodeURIComponent(currentUsername)}&repo=${encodeURIComponent(repo.name)}&branch=${encodeURIComponent(repo.branch || 'main')}&type=folder`);
        const result = await response.json();

        if (result.status === 'success' && result.data) {
            repo.files = Array.isArray(result.data.files) ? result.data.files : [];
            
            // STRICT ROOT README FILTER: Only pick a README file located at the exact repository root
            const rootReadme = repo.files.find(f => {
                if (!f || !f.name) return false;
                const isReadmeName = f.name.toLowerCase() === 'readme.md';
                const cleanPath = (f.path || '').replace(/^\/+/, '');
                const isAtRoot = !cleanPath.includes('/') || cleanPath.lastIndexOf('/') === 0;
                return isReadmeName && isAtRoot;
            });

            repo.readme = rootReadme || result.data.readme || null;
            if (result.data.branch) repo.branch = result.data.branch;
        } else {
            repo.files = [];
            repo.readme = null;
        }
    } catch (e) {
        console.error('Failed to load repository contents', e);
        repo.files = [];
        repo.readme = null;
    }

    const fileEntriesCount = (repo.files && Array.isArray(repo.files)) ? repo.files.length : 0;
    if (fileCountEl) fileCountEl.innerText = `${fileEntriesCount} entries`;
    
    renderFileTree(repo.files || []);

    const bannerContainer = document.getElementById('viewer-banner-container');
    const bannerImg = document.getElementById('viewer-banner-img');
    if (bannerContainer && bannerImg) {
        bannerImg.src = "images/rr.png";
        bannerContainer.classList.remove('hidden');
    }
    
    if (repo.readme) {
        await selectFile(repo.readme);
    } else {
        currentFile = null;
        document.getElementById('current-file-path').innerText = 'Select a file to inspect';
        document.getElementById('viewer-container').innerHTML = `
            <div class="max-w-4xl mx-auto h-full flex flex-col items-center justify-center text-center text-slate-500">
                <h3 class="text-xs font-semibold text-slate-300 mb-1 font-mono">${repo.name || 'Repository'} Loaded</h3>
                <p class="text-[11px] text-slate-500">No README found. Select a file from the tree above.</p>
            </div>
        `;
    }
}
window.selectRepository = selectRepository;

function buildFileTreeStructure(files) {
    const root = { name: '', path: '', type: 'directory', children: {}, files: [] };
    
    files.forEach(file => {
        if (!file.path) return;
        
        const cleanPath = file.path.replace(/^\/+/, '');
        const parts = cleanPath.split('/');
        let current = root;

        for (let i = 0; i < parts.length - 1; i++) {
            const folderName = parts[i];
            if (!folderName) continue;
            
            const subPath = parts.slice(0, i + 1).join('/');
            if (!current.children[folderName]) {
                current.children[folderName] = {
                    name: folderName,
                    path: subPath,
                    type: 'folder',
                    children: {},
                    files: [],
                    loaded: false
                };
            }
            current = current.children[folderName];
        }

        const terminalName = parts[parts.length - 1];
        if (!terminalName) return;

        file.path = cleanPath;

        if (file.type === 'folder') {
            if (!current.children[terminalName]) {
                current.children[terminalName] = {
                    name: terminalName,
                    path: cleanPath,
                    type: 'folder',
                    children: {},
                    files: [],
                    loaded: false
                };
            }
        } else {
            if (!current.files.some(f => f.path === file.path)) {
                current.files.push(file);
            }
        }
    });
    
    return root;
}

function renderFileTree(files) {
    const treeEl = document.getElementById('file-tree');
    if (!treeEl) return;
    treeEl.innerHTML = '';

    const treeData = buildFileTreeStructure(files);

    function renderNode(node, container, depth = 0) {
        Object.keys(node.children).sort().forEach(folderName => {
            const folder = node.children[folderName];
            const folderWrapper = document.createElement('div');
            folderWrapper.className = 'folder-wrapper my-0.5';
            folderWrapper.dataset.folderPath = folder.path;

            const isExpanded = expandedFolders.has(folder.path);

            const folderHeader = document.createElement('div');
            folderHeader.className = 'folder-header flex items-center space-x-1.5 px-2 py-1 rounded-sm cursor-pointer text-xs font-mono text-amber-400 hover:bg-black/50 transition-all';
            folderHeader.style.paddingLeft = `${(depth * 10) + 6}px`;
            folderHeader.innerHTML = `
                <i class="fa-solid ${isExpanded ? 'fa-folder-open' : 'fa-folder'} text-amber-400 w-3 text-center folder-icon-node"></i>
                <span class="truncate">${folder.name}</span>
            `;

            const subContainer = document.createElement('div');
            subContainer.className = 'pl-2 space-y-0.5 folder-subcontainer';
            subContainer.style.display = isExpanded ? 'block' : 'none';

            folderHeader.onclick = async (e) => {
                e.stopPropagation();
                const isHidden = subContainer.style.display === 'none';
                
                if (isHidden) {
                    subContainer.style.display = 'block';
                    expandedFolders.add(folder.path);
                    folderHeader.querySelector('i').className = 'fa-solid fa-folder-open text-amber-400 w-3 text-center folder-icon-node';
                    
                    if (!folder.loaded && folder.path) {
                        await loadFolderContents(folder, subContainer, depth + 1);
                    }
                } else {
                    subContainer.style.display = 'none';
                    expandedFolders.delete(folder.path);
                    folderHeader.querySelector('i').className = 'fa-solid fa-folder text-amber-400 w-3 text-center folder-icon-node';
                }
            };

            folderWrapper.appendChild(folderHeader);
            folderWrapper.appendChild(subContainer);
            container.appendChild(folderWrapper);

            renderNode(folder, subContainer, depth + 1);
        });

        node.files.filter(f => f.type !== 'folder').sort((a, b) => a.name.localeCompare(b.name)).forEach(file => {
            const isSelected = currentFile && currentFile.path === file.path;
            const isMarkdown = file.name.endsWith('.md');
            const isImage = /\.(png|jpg|jpeg|gif|svg|webp|ico)$/i.test(file.name);
            
            const item = document.createElement('div');
            item.className = `file-item flex items-center space-x-1.5 px-2.5 py-1 rounded-sm cursor-pointer text-xs font-mono transition-all ${isSelected ? 'selected' : 'text-slate-300 hover:bg-black/40 hover:text-white'}`;
            item.style.paddingLeft = `${(depth * 10) + 10}px`;
            item.onclick = (e) => {
                e.stopPropagation();
                selectFile(file);
            };

            let iconClass = 'fa-file text-red-500';
            if (isMarkdown) iconClass = 'fa-file-lines text-red-500';
            else if (isImage) iconClass = 'fa-file-image text-amber-400';
            else if (file.name.endsWith('.php')) iconClass = 'fa-file-code text-red-400';
            else if (file.name.endsWith('.js')) iconClass = 'fa-file-code text-amber-400';

            item.innerHTML = `
                <i class="fa-solid ${iconClass} w-3 text-center"></i>
                <span class="truncate">${file.name}</span>
            `;
            container.appendChild(item);
        });
    }

    renderNode(treeData, treeEl);
}

async function loadFolderContents(folderNode, subContainer, depth) {
    if (!currentRepo) return;
    
    subContainer.innerHTML = `<div class="px-2 py-1 text-[10px] text-slate-500 font-mono"><i class="fa-solid fa-spinner animate-spin mr-1"></i> Loading...</div>`;

    const urlParams = new URLSearchParams(window.location.search);
    const isRemoteMode = urlParams.get('git') === 'true';
    const currentRoot = urlParams.get('root') || 'repositories';
    const currentUsername = urlParams.get('user') || 'mercwar';
    const targetEndpoint = isRemoteMode ? 'git.php' : 'php.php';

    try {
        const response = await fetch(`${targetEndpoint}?action=get_file&git=${isRemoteMode}&root=${encodeURIComponent(currentRoot)}&user=${encodeURIComponent(currentUsername)}&repo=${encodeURIComponent(currentRepo.name)}&branch=${encodeURIComponent(currentRepo.branch || 'main')}&path=${encodeURIComponent(folderNode.path)}&type=folder`);
        const result = await response.json();

        if (result.status === 'success' && result.data && Array.isArray(result.data.files)) {
            folderNode.loaded = true;
            subContainer.innerHTML = '';
            
            result.data.files.forEach(subFile => {
                if (folderNode.path && subFile.path) {
                    const cleanSubPath = subFile.path.replace(/^\/+/, '');
                    if (!cleanSubPath.startsWith(folderNode.path)) {
                        subFile.path = `${folderNode.path}/${cleanSubPath}`;
                    }
                } else if (folderNode.path && !subFile.path && subFile.name) {
                    subFile.path = `${folderNode.path}/${subFile.name}`;
                }

                if (!currentRepo.files.some(f => f.path === subFile.path)) {
                    currentRepo.files.push(subFile);
                }
            });

            renderFileTree(currentRepo.files);
        } else {
            subContainer.innerHTML = `<div class="px-2 py-1 text-[10px] text-red-400 font-mono">Failed to load folder</div>`;
        }
    } catch (e) {
        console.error('Failed to load folder contents', e);
        subContainer.innerHTML = `<div class="px-2 py-1 text-[10px] text-red-400 font-mono">Connection error</div>`;
    }
}
window.loadFolderContents = loadFolderContents;

async function selectFile(file) {
    if (!file || file.type === 'folder') return;
    currentFile = file;
    document.getElementById('current-file-path').innerText = `${currentRepo ? currentRepo.name : ''} / ${file.path}`;
    document.getElementById('viewer-container').innerHTML = `<div class="p-12 text-center text-slate-500 text-xs"><i class="fa-solid fa-spinner animate-spin mr-2"></i> Loading file content...</div>`;

    try {
        const urlParams = new URLSearchParams(window.location.search);
        const isRemoteMode = urlParams.get('git') === 'true';
        const currentRoot = urlParams.get('root') || 'repositories';
        const currentUsername = urlParams.get('user') || 'mercwar';
        const repoName = currentRepo ? currentRepo.name : (urlParams.get('repo') || '');
        const targetEndpoint = isRemoteMode ? 'git.php' : 'php.php';

        let filePathParam = '';
        let fileNameParam = file.name;
        
        if (file.path && file.path.includes('/')) {
            const lastSlashIndex = file.path.lastIndexOf('/');
            filePathParam = file.path.substring(0, lastSlashIndex);
            fileNameParam = file.path.substring(lastSlashIndex + 1);
        }

        let finalPath = filePathParam;
        let finalFile = fileNameParam;

        if (isRemoteMode) {
            finalPath = encodeURIComponent(filePathParam);
            finalFile = encodeURIComponent(fileNameParam);
        }
        
        const response = await fetch(`${targetEndpoint}?action=get_file&git=${isRemoteMode}&root=${encodeURIComponent(currentRoot)}&user=${encodeURIComponent(currentUsername)}&repo=${encodeURIComponent(repoName)}&path=${encodeURIComponent(finalPath)}&file=${encodeURIComponent(finalFile)}&type=file`);
        const result = await response.json();
        
        if (result.status === 'success' && result.data) {
            const fileData = {
                path: file.path,
                absolute_path: file.absolute_path,
                name: file.name,
                is_image: result.data.is_image,
                is_markdown: file.name.endsWith('.md') || file.name.endsWith('.markdown'),
                is_html: file.name.endsWith('.html') || file.name.endsWith('.htm'),
                content: result.data.content,
                parsed_content: result.data.parsed_content || ''
            };

            if (fileData.content && !fileData.is_image) {
                fileData.content = preprocessGithubSyntax(fileData.content);
            }

            renderFileContent(fileData);
            if (currentRepo && currentRepo.files) {
                renderFileTree(currentRepo.files);
            }
        } else {
            document.getElementById('viewer-container').innerHTML = `<div class="p-12 text-center text-red-400 text-xs">${result.avis || 'Failed to load file content.'}</div>`;
        }
    } catch (e) {
        console.error('Failed to load file', e);
        document.getElementById('viewer-container').innerHTML = `<div class="p-12 text-center text-red-400 text-xs">Error communicating with backend server.</div>`;
    }
}
window.selectFile = selectFile;

function preprocessGithubSyntax(content) {
    if (!content) return '';
    let processed = content.replace(/!#\[(.*?)\](.*?)/g, (match, altText, imgPath) => `![${altText}](${imgPath})`);
    processed = processed.replace(/#\[(.*?)\](.*?)/g, (match, linkText, urlPath) => `[${linkText}](${urlPath})`);
    return processed;
}

function renderFileContent(fileResponseData) {
    const container = document.getElementById('viewer-container');
    const btnPreview = document.getElementById('btn-preview');
    const btnRaw = document.getElementById('btn-raw');

    currentFile = fileResponseData;

    if (btnPreview) btnPreview.classList.add('hidden');
    if (btnRaw) btnRaw.classList.add('hidden');

    if (fileResponseData.is_image) {
        container.innerHTML = `
            <div class="max-w-4xl mx-auto glass-panel p-5 rounded-sm shadow-xl flex flex-col items-center justify-center">
                <div class="flex items-center justify-between w-full pb-2 mb-3 border-b border-red-900/30 text-[11px] text-slate-400 font-mono">
                    <span>Image Preview (${fileResponseData.name})</span>
                    <a href="${fileResponseData.content}" download="${fileResponseData.name}" class="hover:text-red-400 transition-all">
                        <i class="fa-solid fa-download mr-1"></i> Download
                    </a>
                </div>
                <div class="p-3 bg-black/60 rounded-sm border border-red-900/30 max-h-[70vh] flex items-center justify-center overflow-auto w-full">
                    <img src="${fileResponseData.content}" alt="${fileResponseData.name}" class="max-h-[60vh] object-contain" />
                </div>
            </div>
        `;
        return;
    }

    if (fileResponseData.is_markdown || fileResponseData.is_html) {
        if (btnPreview) btnPreview.classList.remove('hidden');
        if (btnRaw) btnRaw.classList.remove('hidden');

        if (activeViewMode === 'preview') {
            let htmlOutput = '';
            if (fileResponseData.is_html) {
                htmlOutput = `<div class="github-html-container">${fileResponseData.content}</div>`;
            } else {
                const normalizedMarkdown = preprocessGithubSyntax(fileResponseData.content);
                htmlOutput = fileResponseData.parsed_content || (window.marked ? window.marked.parse(normalizedMarkdown) : normalizedMarkdown);
            }

            container.innerHTML = `
                <div class="w-full glass-panel p-6 rounded-sm shadow-xl markdown-body">
                    ${htmlOutput}
                </div>
            `;
        } else {
            renderRawTextSource(fileResponseData.content);
        }
    } else {
        renderRawTextSource(fileResponseData.content);
    }
}

function renderRawTextSource(rawContent) {
    const container = document.getElementById('viewer-container');
    container.innerHTML = `
        <div class="w-full glass-panel p-5 rounded-sm shadow-xl">
            <div class="flex items-center justify-between pb-2 mb-3 border-b border-red-900/30 text-[11px] text-slate-400 font-mono">
                <span>Raw Source Code</span>
                <button onclick="navigator.clipboard.writeText(currentFile.content)" class="hover:text-red-400 transition-all cursor-pointer">
                    <i class="fa-regular fa-copy mr-1"></i> Copy Code
                </button>
            </div>
            <pre class="text-xs text-amber-300 font-mono leading-relaxed overflow-x-auto p-2"><code>${escapeHtml(rawContent || '')}</code></pre>
        </div>
    `;
}

function setViewMode(mode) {
    activeViewMode = mode;
    if (currentFile) renderFileContent(currentFile);
}
window.setViewMode = setViewMode;

function escapeHtml(text) {
    if (!text) return '';
    return text.toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function handleConfigSubmit(event) {
    event.preventDefault();
    const url = new URL(window.location.href);
    
    const gitMode = document.getElementById('env-git-select')?.value || 'false';
    const root = document.getElementById('env-root-input')?.value || 'repositories';
    const user = document.getElementById('env-user-input')?.value || 'mercwar';
    const path = document.getElementById('env-path-input')?.value || '';

    url.searchParams.set('git', gitMode);
    url.searchParams.set('root', root);
    url.searchParams.set('user', user);
    url.searchParams.set('path', path);
    window.history.pushState({}, '', url);

    loadRepositories();
}
window.handleConfigSubmit = handleConfigSubmit;

window.switchServerMode = function(mode) {
    const rootContainer = document.getElementById('http-root-wrapper');
    const gitHidden = document.getElementById('env-git-hidden');

    if (mode === 'file' || mode === 'false') {
        if (rootContainer) rootContainer.style.display = 'flex';
        if (gitHidden) gitHidden.value = 'false';
    } else {
        if (rootContainer) rootContainer.style.display = 'none';
        if (gitHidden) gitHidden.value = 'true';
    }

    const url = new URL(window.location.href);
    url.searchParams.set('git', mode);
    window.history.pushState({}, '', url);
    
    if (typeof loadRepositories === 'function') {
        loadRepositories();
    }
};

// ==========================================================================
// STARGATE / NODE ROUTER POPUP & NAVIGATION (Clean & Consolidated)
// ==========================================================================

function getSelectedNodeTargetUrl() {
    const nodeSelector = document.getElementById('stargate-node-selector');
    const nodeName = nodeSelector ? nodeSelector.value : 'Stargate';
    
    const routeSlug = nodeName.trim();
    return `https://cron.iblogger.org/${routeSlug}`;
}

window.navigateToSelectedNode = function(nodeValue) {
    console.log(`Node Router switched to: ${nodeValue}`);
    const targetUrl = getSelectedNodeTargetUrl();
    window.history.pushState({}, '', targetUrl);
    
    if (typeof loadRepositories === 'function') {
        loadRepositories();
    }
};

window.openSelectedNodePopup = function() {
    const targetUrl = getSelectedNodeTargetUrl();
    const popupWidth = 1024;
    const popupHeight = 768;
    const left = (window.screen.width - popupWidth) / 2;
    const top = (window.screen.height - popupHeight) / 2;
    
    window.open(
        targetUrl, 
        'StargateNodePopup', 
        `width=${popupWidth},height=${popupHeight},top=${top},left=${left},resizable=yes,scrollbars=yes,status=yes`
    );
};

window.openSelectedNodeExternal = function() {
    const targetUrl = getSelectedNodeTargetUrl();
    window.open(targetUrl, '_blank');
};

window.copySelectedNodeUrl = function() {
    const targetUrl = getSelectedNodeTargetUrl();
    navigator.clipboard.writeText(targetUrl).then(() => {
        alert(`Copied node URL: ${targetUrl}`);
    }).catch(err => {
        console.error('Failed to copy node URL:', err);
    });
};

window.toggleBannerImage = function() {
    const wrapper = document.getElementById('banner-image-wrapper');
    const icon = document.getElementById('banner-icon');
    const text = document.getElementById('banner-label');
    
    if (!wrapper) return;

    if (wrapper.style.display === 'none') {
        wrapper.style.display = 'block';
        if (icon) icon.innerText = '🪂';
        if (text) text.innerText = 'Collapse';
    } else {
        wrapper.style.display = 'none';
        if (icon) icon.innerText = '🎉';
        if (text) text.innerText = 'Expand';
    }
};

window.toggleAllFolders = function(collapse) {
    const wrappers = document.querySelectorAll('#file-tree .folder-wrapper');
    
    wrappers.forEach(wrapper => {
        const subContainer = wrapper.querySelector('.folder-subcontainer');
        const folderIcon = wrapper.querySelector('.folder-icon-node');
        const folderPath = wrapper.dataset.folderPath;

        if (!subContainer) return;

        if (collapse) {
            subContainer.style.display = 'none';
            if (folderIcon) folderIcon.className = 'fa-solid fa-folder text-amber-400 w-3 text-center folder-icon-node';
            if (folderPath) expandedFolders.delete(folderPath);
        } else {
            subContainer.style.display = 'block';
            if (folderIcon) folderIcon.className = 'fa-solid fa-folder-open text-amber-400 w-3 text-center folder-icon-node';
            if (folderPath) expandedFolders.add(folderPath);
        }
    });
};