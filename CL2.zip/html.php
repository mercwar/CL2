<header class="app-header-bg glass-panel border-b border-red-900/40 px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4 sticky top-0 z-50">
    <div class="flex items-center space-x-3 w-full md:w-auto">
<!-- Shield container with JavaScript click handling and Tailwind hover classes -->
<div title="Reset CL2" onclick="window.location.href = window.location.pathname;" 
     class="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600/30 to-amber-500/20 border border-red-500/40 flex items-center justify-center shadow-[0_0_15px_rgba(255,59,48,0.3)] shrink-0 cursor-pointer transition-all duration-300
            hover:from-green-600/30 hover:to-emerald-500/20 hover:border-green-500/40 hover:shadow-[0_0_15px_rgba(34,197,94,0.5)] group">
    <i class="fa-solid fa-shield-halved text-red-500 text-lg transition-colors duration-300 group-hover:text-green-400"></i>
</div>

        <div class="w-full">
            <div class="flex items-center space-x-2">
                <h1 class="font-bold tracking-wider text-white text-lg font-mono">Cyborg Live 2</h1>&nbsp;
                <span class="px-2 py-0.5 text-[10px] font-semibold uppercase tracking-widest bg-red-950/60 text-red-400 border border-red-500/40 rounded">Secure v2.4</span>
            </div>
            
            <p class="text-xs text-slate-400 font-mono mb-2">Target Source: <span id="target-source-display" class="text-amber-400"><?= defined('REPO_BASE_DIR') ? htmlspecialchars(REPO_BASE_DIR) : 'Not Set' ?></span></p>

            <div class="w-full max-w-5xl" style="background:#111; color:#0ff; font-family:monospace; padding:10px 15px; border:1px solid #333; border-radius:4px;">
                <!-- AJAX-driven configuration form with hardcoded hidden action flag for form clicks -->
                <form id="env-config-form" onsubmit="handleConfigSubmit(event)" class="margin-0 p-0 flex flex-wrap items-center gap-2">
                    <?php 
                        // Default to false (Files Mode / Local) unless explicitly set to true
                      if (!isset($_GET['git_select'])) {
    $is_http_mode = true;
} else {
    $is_http_mode = ($_GET['git_select'] === 'true');
}

                    ?>
                    <input type="hidden" name="git" id="env-git-hidden" value="<?= $is_http_mode ? 'true' : 'false' ?>">
                    <input type="hidden" name="action" value="form_load">
                    
                    <label class="whitespace-nowrap"><strong>SERVER MODE:</strong> </label>
                    <select name="git_select" id="env-git-select" onchange="switchServerMode(this.value)" style="background:#222; color:#fff; border:1px solid #333; padding:2px;">
                        <option value="false" <?= !$is_http_mode ? 'selected' : '' ?>>Files Mode (Local Drive)</option>
                        <option value="true" <?= $is_http_mode ? 'selected' : '' ?>>HTTP Mode (GitHub Server)</option>
                    </select>
                    
                    <div id="inputs-container" class="flex flex-wrap items-center gap-2">
                        <span class="text-slate-600">|</span>

                        <!-- Always render the element wrapper but toggle its visibility with CSS so JS can target it -->
                        <div id="http-root-wrapper" style="display: <?= !$is_http_mode ? 'flex' : 'none' ?>;" class="items-center gap-2">
                            <label id="label-root">Root:</label>
                            <input type="text" name="root" id="env-root-input" value="<?php echo htmlspecialchars($_GET['root'] ?? ''); ?>" style="background:#222; color:#fff; border:1px solid #0ff; width:120px; padding:2px 4px;" placeholder="https://api...">
                        </div>

                        <label id="label-user">User:</label>
                        <input type="text" name="user" id="env-user-input" value="<?php echo htmlspecialchars($_GET['user'] ?? (defined('USER_NAME') ? USER_NAME : 'mercwar')); ?>" style="background:#222; color:#fff; border:1px solid #0ff; width:90px; padding:2px 4px;">
                        
                        <label id="label-path">Path:</label>
                        <input type="text" name="path" id="env-path-input" value="<?php echo htmlspecialchars($_GET['path'] ?? ''); ?>" style="background:#222; color:#fff; border:1px solid #0ff; width:160px; padding:2px 4px;" placeholder="repositories/folder/file.php">
                        
                        <button type="submit" style="background:#0ff; color:#000; border:none; padding:2px 8px; font-weight:bold; cursor:pointer;">Live Load</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</header>




    <div class="flex items-center space-x-4 shrink-0">
        <button onclick="loadRepositories()" class="px-3.5 py-2 text-xs font-semibold bg-gradient-to-r from-red-950/40 to-transparent border border-red-500/40 text-red-400 hover:bg-red-900/30 transition-all rounded-lg flex items-center space-x-2 shadow-[0_0_10px_rgba(255,59,48,0.15)] cursor-pointer">
            <i class="fa-solid fa-rotate"></i>
            <span>Rescan Repos</span>
        </button>
    </div>
</header>

    <div class="flex-1 flex flex-col md:flex-row overflow-hidden app-layout">
        <aside class="w-full md:w-80 glass-panel border-r border-red-900/30 flex flex-col shrink-0 bg-[#060406]/85">
            <div class="p-4 border-b border-red-900/30 flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <i class="fa-solid fa-folder-tree text-amber-400"></i>
                    <h2 class="text-xs font-bold uppercase tracking-widest text-slate-300 font-mono">Repositories</h2>
                </div>
                <span id="repo-count" class="text-xs font-mono bg-black/60 px-2 py-0.5 rounded text-amber-400 border border-amber-500/30">0 detected</span>
            </div>
            
            <div class="p-3">
                <div class="relative">
                    <i class="fa-solid fa-search absolute left-3 top-2.5 text-slate-500 text-xs"></i>
                    <input type="text" id="repo-search" oninput="filterRepositories()" placeholder="Filter repositories..." class="w-full bg-black/70 border border-red-900/40 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 shadow-inner">
                </div>
            </div>

            <div id="repo-list" class="flex-1 overflow-y-auto px-3 space-y-1 pb-4"></div>
        </aside>

        <!-- Secondary Sidebar: File Tree Browser -->
        <aside class="w-full md:w-80 glass-panel border-r border-red-900/30 flex flex-col shrink-0 bg-[#060406]/85">
            <div class="p-4 border-b border-red-900/30 flex items-center justify-between">
                <div class="flex items-center space-x-2 overflow-hidden">
                    <i class="fa-solid fa-code-branch text-amber-400"></i>
                    <h2 id="active-repo-name" class="text-xs font-bold uppercase tracking-widest text-slate-300 truncate font-mono">Select Repository</h2>
                </div>
                <div class="flex items-center space-x-1.5">
                    <button onclick="toggleAllFolders(true)" title="Collapse All Folders" class="px-2 py-1 text-[10px] bg-black/60 border border-red-900/40 text-slate-300 hover:text-red-400 hover:border-red-500/40 rounded transition-all">
                        <i class="fa-solid ">💤️</i>
                    </button>
                    <button onclick="toggleAllFolders(false)" title="Expand All Folders" class="px-2 py-1 text-[10px] bg-black/60 border border-red-900/40 text-slate-300 hover:text-red-400 hover:border-red-500/40 rounded transition-all">
                        <i class="fa-solid ">📚️</i>
                    </button>
                    <span id="file-count" class="text-xs font-mono bg-black/60 px-2 py-0.5 rounded text-red-400 border border-red-500/30">0 files</span>
                </div>
            </div>

            <div id="file-tree" class="flex-1 overflow-y-auto p-3 text-sm">
                <div class="flex flex-col items-center justify-center h-48 text-center text-slate-500">
                    <i class="fa-regular fa-folder-open text-3xl mb-2 text-slate-600"></i>
                    <p class="text-xs">No active repository selected. Choose one from the sidebar.</p>
                </div>
            </div>
        </aside>

        <main class="flex-1 flex flex-col bg-[#040305] overflow-hidden">
            <div class="glass-panel border-b border-red-900/30 px-6 py-3 flex items-center justify-between bg-[#060406]/90">
                <div class="flex items-center space-x-3 overflow-hidden">
                    <i id="current-file-icon" class="fa-solid fa-file text-slate-400"></i>
                    <span id="current-file-path" class="text-xs font-mono text-slate-300 truncate">No file selected</span>
                </div>
                <div class="flex items-center space-x-2">
                    <button onclick="setViewMode('preview')" id="btn-preview" class="px-3 py-1.5 text-xs font-medium rounded-lg bg-red-600 text-white shadow-[0_0_12px_rgba(255,59,48,0.4)] transition-all hidden">
                        <i class="fa-solid fa-eye mr-1"></i> Rendered Preview
                    </button>
                    <button onclick="setViewMode('raw')" id="btn-raw" class="px-3 py-1.5 text-xs font-medium rounded-lg text-slate-400 hover:text-white bg-black/60 border border-red-900/40 transition-all hidden">
                        <i class="fa-solid fa-code mr-1"></i> Raw Source
                    </button>
                </div>
            </div>

            <!-- Sticky Header Banner for rrpng / Repository Identity Graphic -->
            <div id="viewer-banner-container" class="px-6 pt-4 pb-2 bg-[#040305]/95 border-b border-red-900/20 sticky top-0 z-40 backdrop-blur-md hidden">
<div class="max-w-4xl mx-auto rounded-xl overflow-hidden border border-red-500/30 shadow-[0_4px_20px_rgba(0,0,0,0.8)] bg-black/80">
    <!-- Cyber Action & Navigation Bar -->
    <div class="flex flex-col md:flex-row items-center justify-between px-3 py-2 bg-red-950/40 border-b border-red-900/40 font-mono text-[11px] text-slate-300 gap-2">
        <div class="flex items-center space-x-2">
            <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            <span class="text-cyan-400 font-bold">Portal: </span>
            <!-- Interactive Node Select Dropdown -->
            <select id="stargate-node-selector" onchange="navigateToSelectedNode(this.value)" class="bg-black/75 text-amber-300 border border-cyan-500/40 rounded px-2 py-1 text-xs focus:outline-none focus:border-cyan-400 cursor-pointer">
                <option value="Stargate">Stargate</option>
                <option value="NEXUS">Nexus</option>
                <option value="AVIS-DATALAKE">AVIS-DATALAKE</option>
                <option value="Station">STATION</option>
            </select>
        </div>
        <div class="flex items-center space-x-3">
<button onclick="toggleBannerImage()" class="hover:text-amber-400 transition-all flex items-center space-x-1 cursor-pointer" title="Collapse/Expand Banner Image">
    <span id="banner-icon">🪂</span>
    <span id="banner-label">Collapse&nbsp;</span>
</button>
            <button onclick="openSelectedNodePopup()" class="hover:text-cyan-300 transition-all flex items-center space-x-1 cursor-pointer" title="Open Selected in Popup Window">
                <i class="fa-solid fa-window-maximize text-xs"></i>
                <span>Popup</span>
            </button>
            <button onclick="openSelectedNodeExternal()" class="hover:text-amber-300 transition-all flex items-center space-x-1 cursor-pointer" title="Open in New Tab">
                <i class="fa-solid fa-arrow-up-right-from-square text-xs"></i>
                <span>External</span>
            </button>
            <button onclick="copySelectedNodeUrl()" class="hover:text-red-400 transition-all flex items-center space-x-1 cursor-pointer" title="Copy URL">
                <i class="fa-regular fa-copy text-xs"></i>
                <span>Copy</span>
            </button>
        </div>
    </div>
    <!-- Banner Image Display with an ID wrapper for clean toggling -->
    <div id="banner-image-wrapper" class="transition-all duration-300">
        <div onclick="openSelectedNodeExternal()" class="block relative group cursor-pointer">
            <img id="viewer-banner-img" src="images/rr.png" alt="RRpng Banner" class="w-full h-36 md:h-44 object-cover transition-all group-hover:brightness-110" />
            <div class="absolute inset-0 bg-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
        </div>
    </div>
</div>
            </div>

            <div id="viewer-container" class="flex-1 overflow-y-auto p-6 md:p-8">
                <div class="max-w-4xl mx-auto h-full flex flex-col items-center justify-center text-center text-slate-500">
                    <div class="w-16 h-16 rounded-2xl bg-black/60 border border-red-500/30 flex items-center justify-center mb-4 text-red-500/60 shadow-[0_0_20px_rgba(255,59,48,0.15)]">
                        <i class="fa-solid fa-terminal text-2xl"></i>
                    </div>
                    <h3 class="text-sm font-semibold text-slate-300 mb-1 font-mono">Awaiting Telemetry Input</h3>
                    <p class="text-xs text-slate-500 max-w-sm">Select a repository from the sidebar to automatically load its root README.</p>
                </div>
            </div>
        </main>
    </div>
<footer>
    <!-- Left Data Block -->
    <div>
        <span>
            <span></span>
            <span>AVIS Link Active</span>
        </span>
        <span>|</span>
        <span>Source: Local Drive Scanner (C:\MercwarAI\github\repositories\mercwar)</span>
    </div>
    
    <!-- Right Data Block -->
    <div>
        <span>Encoding: <span>UTF-8</span></span>
        <span>Protocol: <span>REST/Local</span></span>
    </div>
</footer>
