<?php
// ==========================================================================
// AVIS // GitHub Secure Backup Telemetry Viewer - PHP Backend Engine (Remote)
// ==========================================================================

// Include the dedicated GitHub Syntax & Markdown Parser Class
include('cbl.php');
require_once __DIR__ . '/github.php';

if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool {
        return $needle === '' || substr($haystack, -strlen($needle)) === $needle;
    }
}

// Helper function to correctly urlencode multi-segment paths (preserving slashes)
function raw_url_encode_path(string $path): string {
    return implode('/', array_map('rawurlencode', explode('/', $path)));
}

$action = isset($_GET['action']) ? $_GET['action'] : 'list_repos';

while (ob_get_level()) {
    ob_end_clean();
}

header('Content-Type: application/json; charset=utf-8');

// Normalize and clean up username input strings safely
$rawUser = !empty($_GET['user']) ? $_GET['user'] : (defined('USER_NAME') ? USER_NAME : 'mercwar');
$user = trim(str_replace(['/', '\\'], '', $rawUser));
$repoFilter = !empty($_GET['repo']) ? trim(str_replace(['/', '\\'], '', $_GET['repo'])) : '';

// Capture parameters strictly as requested
$pathParam = !empty($_GET['path']) ? trim($_GET['path'], '/') : '';
$fileParam = !empty($_GET['file']) ? trim($_GET['file'], '/') : '';

// Dynamic JSON schema construction
$CONFIG = [
    "owner"      => $user,
    "repo"       => !empty($repoFilter) ? $repoFilter : $user,
    "branch"     => !empty($_GET['branch']) ? $_GET['branch'] : 'main',
    "api_base"   => "https://api.github.com/repos",
    "raw_base"   => "https://raw.githubusercontent.com",
    "pages_base" => "https://" . $user . ".github.io"
];

// GitHub strictly requires a User-Agent header for all unauthenticated requests,
// and cURL provides much better reliability than file_get_contents for GitHub API endpoints.
$getCurlResponse = function($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: AVIS-Telemetry-Viewer-Engine',
        'Accept: application/vnd.github+json'
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
};

if ($action === 'list_repos'  || $action ===  'form_load') {
    $url = "https://api.github.com/users/" . rawurlencode($CONFIG['owner']) . "/repos?per_page=100";
    $response = $getCurlResponse($url);
    
    if ($response === false) {
        echo json_encode([
            'status' => 'error',
            'avis' => 'Local network connection dropped by host wrapper environment.',
            'data' => []
        ]);
        exit;
    }

    $reposData = json_decode($response, true);
    $repos = [];

    if (is_array($reposData)) {
        foreach ($reposData as $repo) {
            if (!isset($repo['name'])) continue;
            
            $repos[] = [
                'name' => $repo['name'],
                'path' => $repo['html_url'] ?? '',
                'branch' => !empty($repo['default_branch']) ? $repo['default_branch'] : 'main',
                'description' => $repo['description'] ?? ''
            ];
        }
    }

    echo json_encode([
        'status' => 'success',
        'avis' => 'Public repositories successfully retrieved.',
        'data' => $repos
    ]);
    exit;

} elseif ($action === 'get_file') {
    // Condition 1: If path is empty AND file is empty -> List root repository contents
    if (empty($pathParam) && empty($fileParam)) {
        if (empty($repoFilter)) {
            echo json_encode([
                'status' => 'error',
                'avis' => 'Repository name is required to list contents.',
                'data' => []
            ]);
            exit;
        }

        $contentsUrl = $CONFIG['api_base'] . "/" . rawurlencode($CONFIG['owner']) . "/" . rawurlencode($repoFilter) . "/contents?ref=" . rawurlencode($CONFIG['branch']);
        $contentsResponse = $getCurlResponse($contentsUrl);
        $items = $contentsResponse ? json_decode($contentsResponse, true) : null;

        $files = [];
        $readmeFile = null;

        if (is_array($items)) {
            if (isset($items['type']) && $items['type'] === 'file') {
                $items = [$items];
            }

            foreach ($items as $node) {
                if (isset($node['name'], $node['path'], $node['type'])) {
                    $isBlob = ($node['type'] === 'file');
                    $files[] = [
                        'name' => $node['name'],
                        'path' => $node['path'],
                        'absolute_path' => $isBlob ? ($CONFIG['raw_base'] . "/" . rawurlencode($CONFIG['owner']) . "/" . rawurlencode($repoFilter) . "/" . rawurlencode($CONFIG['branch']) . "/" . raw_url_encode_path($node['path'])) : '',
                        'type' => $isBlob ? 'file' : 'folder'
                    ];
                }
            }
        }

        foreach ($files as $file) {
            if ($file['type'] === 'file' && strcasecmp($file['name'], 'README.md') === 0) {
                $readmeFile = $file;
                break;
            }
        }

        echo json_encode([
            'status' => 'success',
            'avis' => 'Repository root folders and files successfully retrieved.',
            'data' => [
                'repo' => $repoFilter,
                'branch' => $CONFIG['branch'],
                'path' => '',
                'files' => $files,
                'readme' => $readmeFile
            ]
        ]);
        exit;
    }

    // Condition 2: If path has a value AND file is empty -> List contents of that specific path
    if (!empty($pathParam) && empty($fileParam)) {
        if (empty($repoFilter)) {
            echo json_encode([
                'status' => 'error',
                'avis' => 'Repository name is required to list contents.',
                'data' => []
            ]);
            exit;
        }

        $contentsUrl = $CONFIG['api_base'] . "/" . rawurlencode($CONFIG['owner']) . "/" . rawurlencode($repoFilter) . "/contents/" . raw_url_encode_path($pathParam) . "?ref=" . rawurlencode($CONFIG['branch']);
        $contentsResponse = $getCurlResponse($contentsUrl);
        $items = $contentsResponse ? json_decode($contentsResponse, true) : null;

        $files = [];
        $readmeFile = null;

        if (is_array($items)) {
            if (isset($items['type']) && $items['type'] === 'file') {
                $items = [$items];
            }

            foreach ($items as $node) {
                if (isset($node['name'], $node['path'], $node['type'])) {
                    $isBlob = ($node['type'] === 'file');
                    $files[] = [
                        'name' => $node['name'],
                        'path' => $node['path'],
                        'absolute_path' => $isBlob ? ($CONFIG['raw_base'] . "/" . rawurlencode($CONFIG['owner']) . "/" . rawurlencode($repoFilter) . "/" . rawurlencode($CONFIG['branch']) . "/" . raw_url_encode_path($node['path'])) : '',
                        'type' => $isBlob ? 'file' : 'folder'
                    ];
                }
            }
        }

        foreach ($files as $file) {
            if ($file['type'] === 'file' && strcasecmp($file['name'], 'README.md') === 0) {
                $readmeFile = $file;
                break;
            }
        }

        echo json_encode([
            'status' => 'success',
            'avis' => 'Directory contents successfully retrieved.',
            'data' => [
                'repo' => $repoFilter,
                'branch' => $CONFIG['branch'],
                'path' => $pathParam,
                'files' => $files,
                'readme' => $readmeFile
            ]
        ]);
        exit;
    }

    // Condition 3: File is set and has a value -> Download and render the specific file content
    $targetFilepath = !empty($pathParam) ? $pathParam . '/' . $fileParam : $fileParam;
    $fileUrl = $targetFilepath;

    if (!str_starts_with($fileUrl, 'http://') && !str_starts_with($fileUrl, 'https://')) {
        $cleanPath = ltrim($fileUrl, '/');
        $fileUrl = $CONFIG['raw_base'] . "/" . rawurlencode($CONFIG['owner']) . "/" . rawurlencode($CONFIG['repo']) . "/" . rawurlencode($CONFIG['branch']) . "/" . raw_url_encode_path($cleanPath);
    }

    $content = $getCurlResponse($fileUrl);

    if ($content === false || empty($content)) {
        echo json_encode([
            'status' => 'error',
            'avis' => 'Unable to read the remote file asset target.',
            'debug_url_attempted' => $fileUrl,
            'data' => null
        ]);
        exit;
    }

    $extension = strtolower(pathinfo($fileUrl, PATHINFO_EXTENSION));
    $imageExtensions = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'ico'];

    if (in_array($extension, $imageExtensions)) {
        $base64 = base64_encode($content);
        $mimeType = 'image/' . ($extension === 'svg' ? 'svg+xml' : ($extension === 'jpg' ? 'jpeg' : $extension));
        
        echo json_encode([
            'status' => 'success',
            'avis' => 'Remote image fetched successfully.',
            'data' => [
                'path' => $fileUrl,
                'name' => basename($fileUrl),
                'type' => 'file', // Explicitly aligned so frontend JS recognizes it as a file
                'is_image' => true,
                'content' => "data:{$mimeType};base64,{$base64}"
            ]
        ]);
        exit;
    }

    $parsedContent = $content;
    if (in_array($extension, ['md', 'markdown', 'html', 'htm'])) {
        if (class_exists('GitHubParser')) {
            $parsedContent = GitHubParser::parse($content, $fileUrl);
        }
    }

    echo json_encode([
        'status' => 'success',
        'avis' => 'Remote file loaded and parsed successfully.',
        'data' => [
            'path' => $fileUrl,
            'name' => basename($fileUrl),
            'type' => 'file', // Explicitly aligned so frontend JS recognizes it as a file and avoids raw object dumps
            'is_image' => false,
            'content' => $content,
            'parsed_content' => $parsedContent
        ]
    ]);
    exit;
} else {
    echo json_encode([
        'status' => 'critical',
        'avis' => 'No valid action selected.',
        'data' => null
    ]);
    exit;
}
?>