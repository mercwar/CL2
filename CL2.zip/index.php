<?php
  include('cbl.php');

?>

<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cyborg Live 2</title>
    <script src="https://cdn.tailwindcss.com"></script>


<meta name="description" content="Cyborg Live 2 is an advanced AVIS protocol telemetry terminal and secure repository explorer supporting local drive scanning and GitHub HTTP server modes with real-time 3D WebGL rendering.">
<meta name="keywords" content="Cyborg Live, AVIS protocol, telemetry terminal, GitHub repository viewer, WebGL 3D engine, developer tools, source code inspector">
<meta name="author" content="Robo Rook (Joseph Michael Catalano)">
<meta name="robots" content="index, follow">

<!-- Open Graph / Social Media Meta Tags -->
<meta property="og:type" content="website">
<meta property="og:title" content="Cyborg Live 2 | Secure Telemetry Terminal">
<meta property="og:description" content="Unified GitHub and local protocol telemetry terminal featuring real-time code inspection, markdown rendering, and low-level WebGL 3D pipeline views.">
<meta property="og:image" content="images/rr.png">

<!-- Twitter Card Meta Tags -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Cyborg Live 2 | Secure Telemetry Terminal">
<meta name="twitter:description" content="Unified GitHub and local protocol telemetry terminal featuring real-time code inspection, markdown rendering, and low-level WebGL 3D pipeline views.">
<meta name="twitter:image" content="images/rr.png">
<script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        obsidian: '#040305',
                        glass: '#0a060a',
                        glassborder: 'rgba(255, 59, 48, 0.2)',
                        cyanaccent: '#00F2FF',
                        goldaccent: '#FFD700',
                        crimsonaccent: '#FF3B30',
                        amberaccent: '#FFC107'
                    }
                }
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="style.css">
</head>
<body class="min-h-screen flex flex-col antialiased selection:bg-cyanaccent selection:text-obsidian">

<? include('html.php')?>

    <script type="module" src="js.js<?= '?v='.date('Y-m-d-H-i-s'); ?>"></script>
	  <script type="module" src="dx.js<?= '?v='.date('Y-m-d-H-i-s'); ?>"></script>

</body>
</html>