<?php
// ==========================================================================
// AVIS // Local Repository Backend Driver Engine (php.php)
// Unified PHP backend supporting GitHub API-compatible JSON response protocol
// Accepting 'type' (file or folder) to list contents or return file details
// ==========================================================================

// --- CONFIGURATION SETUP ---
include('cbl.php');
require_once __DIR__ . '/github.php';

// Polyfill function compatibility safety layer (PHP < 8.0 support)
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool {
        return $needle === '' || substr($haystack, -strlen($needle)) === $needle;
    }
}

// Handle AJAX API requests
if (isset($_GET['action'])) {
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    header('Content-Type: application/json; charset=utf-8');
    $action = $_GET['action'];
    $rootParam = !empty($_GET['root']) ? trim($_GET['root'], '\\/') : '';
    $repoFilter = !empty($_GET['repo']) ? trim(str_replace(['/', '\\'], '', $_GET['repo'])) : '';
    
    $pathParam = !empty($_GET['path']) ? trim($_GET['path'], '/') : '';
    
    // Directly parse query string to safely isolate the active file parameter
    $fileParam = '';
    if (!empty($_SERVER['QUERY_STRING'])) {
        foreach (explode('&', $_SERVER['QUERY_STRING']) as $pair) {
            $parts = explode('=', $pair, 2);
            if (count($parts) === 2 && urldecode($parts[0]) === 'file') {
                $val = trim(urldecode($parts[1]), '/');
                if (!empty($val)) {
                    $fileParam = $val; // Keeps the last non-empty file value safely
                }
            }
        }
    }
    if (empty($fileParam) && !empty($_GET['file']) && is_string($_GET['file'])) {
        $fileParam = trim($_GET['file'], '/');
    }

    $type = $_GET['type'] ?? '';
    
    if ($action === 'list_repos' || $action === 'form_load') {
        $repos = [];
        $baseDir = './' . $rootParam . '/' . (defined('USER_NAME') ? USER_NAME : 'mercwar');
        
        $fullPath = $baseDir;
        if (is_dir($baseDir)) {
            $items = scandir($baseDir);
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') continue;
                $itemFullPath = $baseDir . DIRECTORY_SEPARATOR . $item;
                
                if (is_dir($itemFullPath)) {
                    $repos[] = [
                        'name' => $item,
                        'path' => $itemFullPath,
                        'branch' => 'main'
                    ];
                }
            }
        }
        
        echo json_encode([
            'status' => 'success',
            'path' => $fullPath,
            'avis' => 'Repositories successfully scanned from local drive.',
            'data' => $repos
        ]);
        exit;
    }
    
    if ($action === 'get_file') {
        if (empty($repoFilter)) {
            echo json_encode([
                'status' => 'error',
                'avis' => 'Repository parameter is required.',
                'data' => null
            ]);
            exit;
        }

        $baseDir = './' . $rootParam . '/' . (defined('USER_NAME') ? USER_NAME : 'mercwar');
        
        $targetRepoDir = $baseDir . DIRECTORY_SEPARATOR . $repoFilter;
        $realRepoDir = realpath($targetRepoDir);
        $realBase = realpath($baseDir);

        if (!$realRepoDir || !$realBase || !str_starts_with($realRepoDir, $realBase . DIRECTORY_SEPARATOR) || !is_dir($realRepoDir)) {
            echo json_encode([
                'status' => 'error',
                'avis' => 'Repository directory not found locally.',
                'data' => null
            ]);
            exit;
        }

        // Construct target path safely supporting both subpaths and files
        $relativePath = '';
        if (!empty($pathParam) && !empty($fileParam)) {
            if (str_starts_with($fileParam, $pathParam . '/') || str_starts_with($fileParam, $pathParam . '\\')) {
                $relativePath = $fileParam;
            } else {
                $relativePath = rtrim($pathParam, '/') . '/' . ltrim($fileParam, '/');
            }
        } elseif (!empty($pathParam)) {
            $relativePath = $pathParam;
        } elseif (!empty($fileParam)) {
            $relativePath = $fileParam;
        }

        $fullTargetPath = empty($relativePath) ? $realRepoDir : $realRepoDir . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relativePath);
        $realTarget = realpath($fullTargetPath);

        // Fallback check if target is valid within repository boundary
        if (!$realTarget || !str_starts_with($realTarget, $realRepoDir)) {
            $realTarget = $realRepoDir;
        }

        if ($realTarget) {
            // Automatically detect if target is a file even if type wasn't explicitly sent
            $isExplicitFile = ($type === 'file') || (is_file($realTarget) && $type !== 'folder');

            if ($isExplicitFile) {
                if (!is_file($realTarget)) {
                    echo json_encode([
                        'status' => 'error',
                        'avis' => 'File not found: ' . basename($fullTargetPath),
                        'data' => null
                    ]);
                    exit;
                }

                $extension = strtolower(pathinfo($realTarget, PATHINFO_EXTENSION));
                $imageExtensions = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'ico'];
                $isImage = in_array($extension, $imageExtensions);

                $content = @file_get_contents($realTarget);
                if ($content === false) {
                    echo json_encode([
                        'status' => 'error',
                        'avis' => 'Failed to read file contents.',
                        'data' => null
                    ]);
                    exit;
                }

                if ($isImage) {
                    $mimeType = 'application/octet-stream';
                    if (function_exists('finfo_open')) {
                        $finfo = @finfo_open(FILEINFO_MIME_TYPE);
                        if ($finfo) {
                            $detected = @finfo_file($finfo, $realTarget);
                            if ($detected) {
                                $mimeType = $detected;
                            }
                            @finfo_close($finfo);
                        }
                    } else {
                        $mimeTypes = [
                            'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
                            'gif' => 'image/gif', 'svg' => 'image/svg+xml', 'webp' => 'image/webp', 'ico' => 'image/x-icon'
                        ];
                        if (isset($mimeTypes[$extension])) {
                            $mimeType = $mimeTypes[$extension];
                        }
                    }
                    $content = 'data:' . $mimeType . ';base64,' . base64_encode($content);
                }

                $parsedContent = $content;
                if (!$isImage && in_array($extension, ['md', 'markdown', 'html', 'htm'])) {
                    if (class_exists('GitHubParser') && method_exists('GitHubParser', 'parse')) {
                        $parsedContent = GitHubParser::parse($content, $realTarget);
                    }
                }

                echo json_encode([
                    'status' => 'success',
                    'avis' => 'File loaded successfully.',
                    'type' => 'file',
                    'data' => [
                        'name' => basename($realTarget),
                        'path' => $relativePath,
                        'absolute_path' => $realTarget,
                        'is_image' => $isImage,
                        'content' => $content,
                        'parsed_content' => $parsedContent
                    ]
                ]);
                exit;
            }

            // Treat as folder/directory listing
            $scanPath = (is_dir($realTarget)) ? $realTarget : $realRepoDir;
            $files = scanFilesRecursive($scanPath, $realRepoDir);

            $branch = 'main';
            $headFile = $realRepoDir . DIRECTORY_SEPARATOR . 'HEAD';
            if (!file_exists($headFile)) {
                $headFile = $realRepoDir . DIRECTORY_SEPARATOR . '.git' . DIRECTORY_SEPARATOR . 'HEAD';
            }
            if (file_exists($headFile)) {
                $headContent = trim(@file_get_contents($headFile));
                if (str_starts_with($headContent, 'ref: refs/heads/')) {
                    $branch = basename($headContent);
                }
            }

            $readmeFile = null;
            foreach ($files as $file) {
                if ($file['type'] !== 'folder' && preg_match('/^README(\.md)?$/i', $file['name']) && !$readmeFile) {
                    $readmeFile = $file;
                }
            }
            if (!$readmeFile) {
                foreach ($files as $file) {
                    if ($file['type'] !== 'folder' && str_ends_with(strtolower($file['path']), '.md')) {
                        $readmeFile = $file;
                        break;
                    }
                }
            }

            echo json_encode([
                'status' => 'success',
                'avis' => 'Directory contents successfully retrieved.',
                'type' => 'folder',
                'data' => [
                    'repo' => $repoFilter,
                    'branch' => $branch,
                    'path' => $pathParam,
                    'files' => $files,
                    'readme' => $readmeFile,
                    'type' => 'folder'
                ]
            ]);
            exit;
        }

        echo json_encode([
            'status' => 'error',
            'avis' => 'File or directory not found or access denied.',
            'data' => null
        ]);
        exit;
    }

    if ($action === 'raw_file') {
        $filePath = $_GET['path'] ?? '';
        
        if (($pos = strpos($filePath, '?')) !== false) {
            $filePath = substr($filePath, 0, $pos);
        }

        $baseDir = './' . $rootParam . '/' . (defined('USER_NAME') ? USER_NAME : 'mercwar');
        $realBase = realpath($baseDir);

        $targetPath = $baseDir;
        if (!empty($repoFilter)) {
            $targetPath .= DIRECTORY_SEPARATOR . $repoFilter;
        }
        if (!empty($filePath)) {
            $targetPath .= DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath);
        }

        $realTarget = realpath($targetPath);

        if ($realTarget && $realBase && str_starts_with($realTarget, $realBase) && is_file($realTarget)) {
            $extension = strtolower(pathinfo($realTarget, PATHINFO_EXTENSION));
            $mimeTypes = [
                'png' => 'image/png',
                'jpg' => 'image/jpeg',
                'jpeg' => 'image/jpeg',
                'gif' => 'image/gif',
                'svg' => 'image/svg+xml',
                'webp' => 'image/webp',
                'ico' => 'image/x-icon'
            ];
            
            $mimeType = $mimeTypes[$extension] ?? 'application/octet-stream';
            
            header_remove('Content-Type');
            header('Content-Type: ' . $mimeType);
            readfile($realTarget);
            exit;
        }
        http_response_code(404);
        exit;
    }
}

function scanFilesRecursive(string $dir, string $baseDir): array {
    $results = [];
    $items = @scandir($dir);
    if (!is_array($items)) return $results;
    
    $baseDir = rtrim($baseDir, '\\/') . DIRECTORY_SEPARATOR;

    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item === '.git' || $item === 'objects' || $item === 'info') continue;
        
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        $relativePath = ltrim(str_replace($baseDir, '', $path), '\\/');
        $normalizedRelative = str_replace('\\', '/', $relativePath);
        $isDir = is_dir($path);
        
        $results[] = [
            'name' => $item,
            'path' => $normalizedRelative,
            'absolute_path' => $path,
            'type' => $isDir ? 'folder' : 'file'
        ];

        if ($isDir) {
            $results = array_merge($results, scanFilesRecursive($path, rtrim($baseDir, '\\/')));
        }
    }
    return $results;
}
?>