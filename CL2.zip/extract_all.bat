@echo off
setlocal enabledelayedexpansion

set "TARGET_DIR=C:\MercwarAI\github\repositories\mercwar"

echo Scanning: %TARGET_DIR%
echo ----------------------------------------

for /d %%G in ("%TARGET_DIR%\*.git") do (
    echo Found repo: "%%~fG"
    set "WORK_DIR=%%~dpnG"
    echo Target Work Tree: "!WORK_DIR!"

    :: 1. Ensure the working directory folder exists on disk
    if not exist "!WORK_DIR!" (
        mkdir "!WORK_DIR!"
    )

    :: 2. Configure Git to disable bare mode and lock in the worktree path
    git --git-dir="%%~fG" config core.bare false
    git --git-dir="%%~fG" config core.worktree "!WORK_DIR!"

    :: 3. Hard reset the working tree to match HEAD completely (bypasses branch name checks)
    git --git-dir="%%~fG" --work-tree="!WORK_DIR!" reset --hard HEAD
    
    if errorlevel 1 (
        echo [WARNING] Reset failed for "%%~nG", attempting branch checkout fallback...
        git --git-dir="%%~fG" --work-tree="!WORK_DIR!" checkout -f main 2>nul || ^
        git --git-dir="%%~fG" --work-tree="!WORK_DIR!" checkout -f master 2>nul || ^
        git --git-dir="%%~fG" --work-tree="!WORK_DIR!" checkout -f dev 2>nul
    ) else (
        echo [SUCCESS] Restored from HEAD.
    )
    
    echo ----------------------------------------
)

echo All repository streams successfully synchronized.
pause