<?php
// ==========================================================================
// AVIS // Comprehensive GitHub Flavored Markdown (GFM) Parser Class
// Fixed HTML Tag Support, Markdown Headers, and Root-Relative Asset Resolution
// ==========================================================================

class GitHubParser {
    
    public static function parse(string $content, string $filePath = ''): string {
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        
        if ($extension === 'html' || $extension === 'htm') {
            return self::parseHtml($content, $filePath);
        }
        
        return self::parseMarkdown($content, $filePath);
    }

    private static function parseHtml(string $content, string $filePath): string {
        $processed = self::resolveAssetPaths($content, $filePath);
        return '<div class="github-html-container">' . $processed . '</div>';
    }

    private static function parseMarkdown(string $content, string $filePath = ''): string {
        $text = str_replace(["\r\n", "\r"], "\n", $content);
        
        // Clean up frontmatter if present
        if (str_starts_with(trim($text), '---')) {
            $endFront = strpos($text, '---', 3);
            if ($endFront !== false) {
                $text = trim(substr($text, $endFront + 3));
            }
        }

        // 1. Replace all ``` code fences globally with a clean divider line
        $text = preg_replace('/```[a-zA-Z0-9_-]*\n?/', '<div class="text-red-500 font-mono my-2">• • • • • • • • • • • • •</div>', $text);
        $text = str_replace('```', '<div class="text-red-500 font-mono my-2">• • • • • • • • • • • • •</div>', $text);

        // 2. Resolve relative paths for Markdown images `![alt](path)` and HTML `<img src="path">` / `<a href="...">`
        $text = self::resolveAssetPaths($text, $filePath);

        // 3. Parse GFM Tables
        $text = self::parseTables($text);

        // 4. Parse GFM Alert Callouts
        $text = preg_replace_callback(
            '/^> ?\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*\n((?:> ?.*\n?)+)/im',
            function($matches) {
                $type = strtoupper($matches[1]);
                $bodyLines = explode("\n", trim($matches[2]));
                $cleanedBody = [];
                foreach ($bodyLines as $line) {
                    $cleanedBody[] = preg_replace('/^>\s?/', '', $line);
                }
                $htmlBody = implode('<br />', $cleanedBody);

                $colors = [ 'NOTE' => 'text-cyan-300', 'TIP' => 'text-emerald-300', 'IMPORTANT' => 'text-amber-200', 'WARNING' => 'text-red-300', 'CAUTION' => 'text-rose-200', ];
                $colorClass = $colors[$type] ?? 'text-cyan-300';

                return '<div class="my-2 pl-3 border-l-2 border-red-500 font-mono text-xs ' . $colorClass . '">' .
                       '<span class="font-bold">● ' . $type . ':</span> ' . $htmlBody .
                       '</div>';
            },
            $text
        );

        // 5. Replace Horizontal Rules (`---` or `***`)
        $text = preg_replace('/^\s*([-*_])\s*\1\s*\1+\s*$/m', '<div class="text-red-500/60 font-mono my-3">· ─ · ─ · ─ · ─ · ─ · ─ ·</div>', $text);

        // 6. Replace Headers (#, ##, ###) properly so they render correctly
        $text = preg_replace('/^#\s+(.*?)$/m', '<div class="text-red-500 font-bold font-mono text-sm my-3">◆ $1</div>', $text);
        $text = preg_replace('/^##\s+(.*?)$/m', '<div class="text-slate-100 font-semibold font-mono text-xs my-2.5">◇ $1</div>', $text);
        $text = preg_replace('/^###\s+(.*?)$/m', '<div class="text-amber-400 font-mono text-xs my-2">• $1</div>', $text);

        // 7. GFM Task Lists
        $text = preg_replace('/^\s*-\s*\[ \]\s*(.*?)$/m', '<div class="flex items-center space-x-2 my-1 text-slate-300 font-mono text-xs"><span class="text-red-500">○</span><span>$1</span></div>', $text);
        $text = preg_replace('/^\s*-\s*\[x\]\s*(.*?)$/mi', '<div class="flex items-center space-x-2 my-1 text-slate-400 font-mono text-xs line-through"><span class="text-emerald-500">●</span><span>$1</span></div>', $text);

        // 8. Formatting
        $text = preg_replace('/\*\*(.*?)\*\*/s', '<strong class="text-white font-bold">$1</strong>', $text);
        $text = preg_replace('/\*(.*?)\*/s', '<em class="italic text-slate-300">$1</em>', $text);
        $text = preg_replace('/~~(.*?)~~/s', '<del class="text-slate-500 line-through">$1</del>', $text);
        $text = preg_replace('/==(.*?)==/s', '<mark class="bg-amber-500/20 text-amber-200 px-1">$1</mark>', $text);

        // 9. Inline Code & Keyboard Keys
        $text = preg_replace('/`([^`]+)`/', '<code class="text-amber-300 font-mono text-xs">`$1`</code>', $text);$text = preg_replace('/<kbd>(.*?)<\/kbd>/s', '<kbd class="text-xs font-mono text-slate-200">[$1]</kbd>',$text);

        // 10. Mentions & Issues
        $text = preg_replace('/(?<!\w)@([a-zA-Z0-9_-]+)/', '<a href="[https://github.com/$1](https://github.com/$1)" target="_blank" class="text-cyan-400 font-mono hover:underline">@$1</a>', $text);$text = preg_replace('/(?<!\w)#([0-9]+)/', '<a href="[https://github.com/issues/$1](https://github.com/issues/$1)" target="_blank" class="text-amber-400 font-mono hover:underline">#$1</a>',$text);

        // 11. Lists
        $text = preg_replace('/^\* (.*?)$/m', '<div class="text-slate-300 font-mono text-xs my-0.5 pl-3">• $1</div>',$text);
        $text = preg_replace('/^- (.*?)$/m', '<div class="text-slate-300 font-mono text-xs my-0.5 pl-3">- $1</div>',$text);

        // 12. Blockquotes
        $text = preg_replace('/^> (.*?)$/m', '<div class="text-slate-400 font-mono text-xs italic pl-3 my-1 border-l border-red-500/50">“$1”</div>',$text);

        // 13. Paragraphs (Skipping lines that contain HTML elements like images/links/containers)
        $lines = explode("\n", $text);$parsedLines = [];
        foreach ($lines as$line) {
            $trimmed = trim($line);
            if (!empty($trimmed) && !str_starts_with($trimmed, '<')) {$parsedLines[] = '<p class="text-slate-300 leading-relaxed my-1.5">' . $trimmed . '</p>';
            } else {
                $parsedLines[] =$line;
            }
        }

        return implode("\n", $parsedLines);
    }
	
private static function resolveAssetPaths(string $text, string $filePath): string {
    $isRemote = (isset($_GET['git']) && $_GET['git'] === 'true');
    $user = $_GET['user'] ?? 'mercwar';
    $repo = $_GET['repo'] ?? '';
    $branch = $_GET['branch'] ?? 'main';

    $prefix = '';
    if (!empty($filePath)) {
        $normalizedPath = str_replace('\\', '/', $filePath);
        $normalizedPath = preg_replace('/^[a-zA-Z]:/', '', $normalizedPath);
        
        // Extract unique relative subpath after 'repositories/' to build a clean base URL
        if (($pos = stripos($normalizedPath, 'repositories/')) !== false) {
            $subPath = substr($normalizedPath, $pos);
            $dir = dirname($subPath);
            if ($dir !== '.' && $dir !== '') {
                $prefix = trim($dir, '/') . '/';
            }
        }
    }

    $transformUrl = function(string $url) use ($isRemote, $user, $repo, $branch, $prefix): string {
        $url = trim($url, " \t\n\r\0\x0B\"'");
        if (empty($url)) return '';

        // Skip non-GitHub absolute links, hashes, data URIs, and mailto links
        if ((self::isAbsoluteUrl($url) && strpos($url, 'github.com') === false) || str_starts_with($url, '#') || str_starts_with($url, 'data:') || str_starts_with($url, 'mailto:')) {
            return $url;
        }

        // 1. Convert absolute github.com blob URLs to the exact raw format with /refs/heads/
        if (strpos($url, 'github.com') !== false && strpos($url, '/blob/') !== false) {
            // Replaces ://github.com with the exact raw structure
            $pattern = '/github\.com\/([^\/]+)\/([^\/]+)\/blob\/([^\/]+)\/(.+)/i';
            if (preg_match($pattern, $url, $matches)) {
                return "https://raw.githubusercontent.com/{$matches[1]}/{$matches[2]}/refs/heads/{$matches[3]}/{$matches[4]}";
            }
        }

        // Safe relative path cleanup
        $cleanUrl = $url;
        if (str_starts_with($cleanUrl, './')) {
            $cleanUrl = substr($cleanUrl, 2);
        }

        // 2. Format relative paths to match the exact raw endpoint schema
        if ($isRemote && !empty($repo)) {
            $targetPath = ltrim($prefix . $cleanUrl, '/');
            // Raw URL structure requires inserting 'refs/heads/' before the target branch name
            return "https://raw.githubusercontent.com/{$user}/{$repo}/refs/heads/{$branch}/{$targetPath}";
        } else {
            // Local fallback routing
            $root = $_GET['root'] ?? 'repositories';
            if (!empty($repo)) {
                return "{$root}/{$user}/{$repo}/" . $cleanUrl;
            }
            return $cleanUrl;
        }
    };


    // 1. Target and convert standard Markdown images first
    $text = preg_replace_callback('/!\[(.*?)\]\((.*?)\)/s', function($matches) use ($transformUrl) {
        $rawAlt = trim($matches[1]);
        $altText = !empty($rawAlt) ? htmlspecialchars($rawAlt) : 'Telemetry Asset';
        $imgUrl = $transformUrl($matches[2]);
        
        return '<div class="my-3 text-center"><img src="' . htmlspecialchars($imgUrl) . '" alt="' . $altText . '" class="max-h-[380px] mx-auto object-contain border border-cyan-500/30 rounded" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'block\';" /><div class="text-[10px] font-mono text-red-400 hidden">[Asset Missing: ' . $altText . ' | Tried: ' . htmlspecialchars($imgUrl) . ']</div></div>';
    }, $text);

    // 2. Target and capture explicit inline HTML <img> tags
    $text = preg_replace_callback('/<img\b([^>]+)>/i', function($matches) use ($transformUrl) {
        if (str_contains($matches[0], 'border-cyan-500/30')) {
            return $matches[0];
        }

        $attrs = $matches[1];
        preg_match('/src\s*=\s*(["\']?)(.*?)\1/is', $attrs, $srcMatch);
        preg_match('/alt\s*=\s*(["\']?)(.*?)\1/is', $attrs, $altMatch);
        
        $src = $transformUrl($srcMatch[2] ?? '');
        $alt = htmlspecialchars($altMatch[2] ?? 'Telemetry Image');

        return '<div class="my-3 text-center"><img src="' . htmlspecialchars($src) . '" alt="' . $alt . '" class="max-h-[380px] mx-auto object-contain border border-cyan-500/30 rounded" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'block\';" /><div class="text-[10px] font-mono text-red-400 hidden">[Asset Missing: ' . $alt . ' | Tried: ' . htmlspecialchars($src) . ']</div></div>';
    }, $text);

    // 3. Catch-all pass for standard link tags (href attributes)
    $text = preg_replace_callback('/(src|href)=["\']([^"\']+)["\']/i', function($matches) use ($transformUrl) {
        if (str_contains($matches[0], 'border-cyan-500/30')) {
            return $matches[0];
        }
        return $matches[1] . '="' . $transformUrl($matches[2]) . '"';
    }, $text);

    return $text;
}

    private static function isAbsoluteUrl(string $url): bool {
        return str_starts_with($url, 'http://') || 
               str_starts_with($url, 'https://') || 
               str_starts_with($url, 'data:') || 
               str_starts_with($url, '/');
    }

    private static function parseTables(string $text): string {
        $lines = explode("\n", $text);
        $output = [];$inTable = false;
        $tableRows = [];

        foreach ($lines as$line) {
            $trimmed = trim($line);
            if (str_starts_with($trimmed, '|') && str_ends_with($trimmed, '\vert{}')) {$inTable = true;
                $tableRows[] =$trimmed;
            } else {
                if ($inTable) {
                    $output[] = self::buildTableHtml($tableRows);
                    $tableRows = [];$inTable = false;
                }
                $output[] =$line;
            }
        }
        if ($inTable) {
            $output[] = self::buildTableHtml($tableRows);
        }

        return implode("\n", $output);
    }

    private static function buildTableHtml(array $rows): string {
        if (count($rows) < 2) return implode("\n", $rows);

        $html = '<div class="overflow-x-auto my-3"><table class="w-full text-left border-collapse font-mono text-xs border border-red-950">';
        
        $headerCells = array_map('trim', explode('\vert{}\vert{}', trim($rows[0], '|')));
        if (count($headerCells) === 1) {$headerCells = array_map('trim', explode('|', trim($rows[0], '\vert{}'))); }$html .= '<thead><tr class="bg-red-950/20 border-b border-red-950 text-amber-300">';
        foreach ($headerCells as$cell) {
            if ($cell === '') continue;
            $html .= '<th class="px-3 py-2 font-semibold">' . htmlspecialchars($cell) . '</th>';
        }
        $html .= '</tr></thead>';

        $alignments = [];
        $sepCells = array_map('trim', explode('\vert{}\vert{}', trim($rows[1], '|')));
        if (count($sepCells) === 1) {
            $sepCells = array_map('trim', explode('\vert{}', trim($rows[1], '|')));
        }
        foreach ($sepCells as$sep) {
            if ($sep === '') continue;
            if (str_starts_with($sep, ':') && str_ends_with($sep, ':')) {$alignments[] = 'text-center';
            } elseif (str_ends_with($sep, ':')) {$alignments[] = 'text-right';
            } else {
                $alignments[] = 'text-left';
            }
        }

        $html .= '<tbody class="divide-y divide-red-950/40 bg-black/20">';
        for ($i = 2; $i < count($rows); $i++) {$bodyCells = array_map('trim', explode('||', trim($rows[$i], '|')));
            if (count($bodyCells) === 1) {$bodyCells = array_map('trim', explode('|', trim($rows[$i], '|')));
            }
            $bodyCells = array_values(array_filter($bodyCells, fn($c,$idx) => !($idx === 0 &&$c === '') && !($idx === count($bodyCells)-1 && $c === ''), ARRAY_FILTER_USE_BOTH));$html .= '<tr class="hover:bg-red-950/10 transition-all text-slate-300">';
            foreach ($bodyCells as $colIdx =>$cell) {
                $align =$alignments[$colIdx] ?? 'text-left';$html .= '<td class="px-3 py-1.5 ' . $align . '">' . htmlspecialchars($cell) . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table></div>';

        return $html;
    }
}
?>